// ignore: import_of_legacy_library_into_null_safe
import 'package:integration_test/integration_test_driver.dart';

Future<void> main() => integrationDriver();
