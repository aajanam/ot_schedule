package com.aajanam.otschedule

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
