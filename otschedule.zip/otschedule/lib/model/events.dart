
import 'package:cloud_firestore/cloud_firestore.dart';

class Events{
  final String eventId;
  final String creatorId;
  final String date;
  final String diagnose;
  final String doctorName;
  final String procedure;
  final String patientName;
  final String oT;
  final int startHour;
  final int endHour;
  final List bookTime;
  final Timestamp created;

  Events({
    this.date,
    this.diagnose,
    this.doctorName,
    this.endHour,
    this.eventId,
    this.creatorId,
    this.oT,
    this.patientName,
    this.procedure,
    this.startHour,
    this.bookTime,
    this.created,
});


  factory Events.fromJson(Map<String, dynamic> json){
    return Events(
      date: json['date'],
      doctorName: json['doctorName'],
      diagnose: json['diagnose'],
      endHour: json['endHour'],
      eventId: json['eventId'],
      creatorId: json['creatorId'],
      oT: json['oT'],
      patientName: json['patientName'],
      procedure: json['procedure'],
      startHour: json['startHour'],
      bookTime: json['bookTime'],
      created: json['created'],
    );
  }

  Map<String, dynamic> toMap(){
    return {
      'date': date,
      'doctorName': doctorName,
      'diagnose': diagnose,
      'endHour': endHour,
      'eventId': eventId,
      'creatorId': creatorId,
      'oT': oT,
      'patientName': patientName,
      'procedure': procedure,
      'startHour': startHour,
      'bookTime': bookTime,
      'created': created,
    };
  }
}