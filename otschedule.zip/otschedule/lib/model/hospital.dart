

class Hospitals {
  final String name;
  final List members;
  final int numOt;

  Hospitals({this.name, this.members, this.numOt});

  factory Hospitals.fromJson(Map<String, dynamic> json){
    return Hospitals(
      name: json['name'],
      members: json['members'],
      numOt: json['numOt'],
    );
  }

  Map<String,dynamic> toMap(){
    return {
      'name': name,
      'members':members,
      'numOt':numOt,
    };
  }
}
